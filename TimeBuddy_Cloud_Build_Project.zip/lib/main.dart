import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:intl/intl.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  runApp(const TimeBuddyApp());
}

class City {
  const City(this.name, this.country, this.zone);
  final String name;
  final String country;
  final String zone;
}

const cities = <City>[
  City('New York', 'USA', 'America/New_York'),
  City('Los Angeles', 'USA', 'America/Los_Angeles'),
  City('Chicago', 'USA', 'America/Chicago'),
  City('Denver', 'USA', 'America/Denver'),
  City('Toronto', 'Canada', 'America/Toronto'),
  City('Vancouver', 'Canada', 'America/Vancouver'),
  City('London', 'UK', 'Europe/London'),
  City('Manchester', 'UK', 'Europe/London'),
  City('Dhaka', 'Bangladesh', 'Asia/Dhaka'),
  City('Tokyo', 'Japan', 'Asia/Tokyo'),
  City('Dubai', 'UAE', 'Asia/Dubai'),
  City('Sydney', 'Australia', 'Australia/Sydney'),
];

class TimeBuddyApp extends StatefulWidget {
  const TimeBuddyApp({super.key});
  @override
  State<TimeBuddyApp> createState() => _TimeBuddyAppState();
}

class _TimeBuddyAppState extends State<TimeBuddyApp> {
  bool dark = false;
  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF356AE6);
    return MaterialApp(
      title: 'TimeBuddy',
      debugShowCheckedModeBanner: false,
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        cardTheme: const CardThemeData(color: Colors.white, elevation: 0, margin: EdgeInsets.zero),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF7F8FC), surfaceTintColor: Colors.transparent),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
      ),
      home: HomeScreen(dark: dark, onThemeChanged: (v) => setState(() => dark = v)),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.dark, required this.onThemeChanged});
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final TabController tabs;
  Set<String> favorites = {'America/New_York', 'Europe/London', 'America/Toronto'};
  String search = '';
  City from = cities.first;
  City to = cities[6];
  DateTime meeting = DateTime.now();

  @override
  void initState() {
    super.initState();
    tabs = TabController(length: 3, vsync: this);
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('favorites');
    if (saved != null && mounted) setState(() => favorites = saved.toSet());
  }

  Future<void> _toggleFavorite(City city) async {
    setState(() {
      if (!favorites.add(city.zone)) favorites.remove(city.zone);
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', favorites.toList());
  }

  String _time(City city, {DateTime? at}) {
    final location = tz.getLocation(city.zone);
    final value = at == null
        ? tz.TZDateTime.now(location)
        : tz.TZDateTime.from(at, location);
    return DateFormat('h:mm a').format(value);
  }

  String _date(City city) {
    final value = tz.TZDateTime.now(tz.getLocation(city.zone));
    return DateFormat('EEE, MMM d').format(value);
  }

  @override
  void dispose() {
    tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final visible = cities.where((c) =>
      (favorites.contains(c.zone) || search.isNotEmpty) &&
      ('${c.name} ${c.country}'.toLowerCase().contains(search.toLowerCase()))
    ).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.public, color: Color(0xFF356AE6), size: 27),
          SizedBox(width: 9),
          Text('TimeBuddy', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -0.5)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Toggle theme',
            onPressed: () => widget.onThemeChanged(!widget.dark),
            icon: Icon(isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
          ),
          const SizedBox(width: 8),
        ],
        bottom: TabBar(
          controller: tabs,
          labelColor: const Color(0xFF356AE6),
          tabs: const [
            Tab(text: 'World Clock', icon: Icon(Icons.public)),
            Tab(text: 'Converter', icon: Icon(Icons.swap_horiz)),
            Tab(text: 'Meeting', icon: Icon(Icons.event_available)),
          ],
        ),
      ),
      body: TabBarView(controller: tabs, children: [
        _worldClock(visible),
        _converter(),
        _meeting(),
      ]),
    );
  }

  Widget _worldClock(List<City> visible) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
      children: [
        Text('Your world, at a glance', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text('Current local times around the world.', style: TextStyle(color: Colors.grey.shade600)),
        const SizedBox(height: 18),
        TextField(
          decoration: InputDecoration(
            hintText: 'Search city or country',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Theme.of(context).cardColor,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
          onChanged: (v) => setState(() => search = v),
        ),
        const SizedBox(height: 14),
        if (visible.isEmpty)
          const Padding(padding: EdgeInsets.all(28), child: Center(child: Text('No cities found. Try another search.'))),
        ...visible.map((city) => _cityCard(city)),
        const SizedBox(height: 10),
        Text('Popular cities', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: cities.where((c) => !favorites.contains(c.zone)).take(8).map((c) =>
            ActionChip(label: Text(c.name), onPressed: () => _toggleFavorite(c))
          ).toList(),
        ),
      ],
    );
  }

  Widget _cityCard(City city) {
    final fav = favorites.contains(city.zone);
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        child: Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(color: const Color(0xFFEAF0FF), borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.location_city, color: Color(0xFF356AE6)),
          ),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(city.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            Text('${city.country}  •  ${_date(city)}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(_time(city), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 19)),
            Text(city.zone.split('/').last.replaceAll('_', ' '), style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
          ]),
          IconButton(
            tooltip: fav ? 'Remove favorite' : 'Add favorite',
            onPressed: () => _toggleFavorite(city),
            icon: Icon(fav ? Icons.star : Icons.star_border, color: fav ? const Color(0xFFFFB020) : Colors.grey),
          ),
        ]),
      ),
    );
  }

  Widget _cityDropdown(City value, ValueChanged<City?> onChanged) {
    return DropdownButtonFormField<City>(
      value: value,
      isExpanded: true,
      decoration: InputDecoration(
        filled: true, fillColor: Theme.of(context).cardColor,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
      items: cities.map((c) => DropdownMenuItem(value: c, child: Text('${c.name}, ${c.country}', overflow: TextOverflow.ellipsis))).toList(),
      onChanged: onChanged,
    );
  }

  Widget _converter() {
    final converted = tz.TZDateTime.from(meeting, tz.getLocation(to.zone));
    return ListView(padding: const EdgeInsets.all(18), children: [
      Text('Time zone converter', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      Text('Compare the same moment in two cities.', style: TextStyle(color: Colors.grey.shade600)),
      const SizedBox(height: 22),
      const Text('FROM', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF356AE6), letterSpacing: 1)),
      const SizedBox(height: 8),
      _cityDropdown(from, (v) => setState(() { if (v != null) from = v; })),
      const SizedBox(height: 18),
      const Text('TO', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF356AE6), letterSpacing: 1)),
      const SizedBox(height: 8),
      _cityDropdown(to, (v) => setState(() { if (v != null) to = v; })),
      const SizedBox(height: 18),
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Selected date & time', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Text(DateFormat('EEEE, MMM d, yyyy • h:mm a').format(meeting), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () async {
              final date = await showDatePicker(context: context, initialDate: meeting, firstDate: DateTime(2000), lastDate: DateTime(2100));
              if (date == null || !mounted) return;
              final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(meeting));
              if (time == null) return;
              setState(() => meeting = DateTime(date.year, date.month, date.day, time.hour, time.minute));
            },
            icon: const Icon(Icons.edit_calendar), label: const Text('Choose date & time'),
          ),
        ]),
      )),
      const SizedBox(height: 14),
      Card(color: const Color(0xFFEAF0FF), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('TIME IN DESTINATION', style: TextStyle(color: Color(0xFF356AE6), fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 8),
          Text(DateFormat('h:mm a').format(converted), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Color(0xFF173B91))),
          Text(DateFormat('EEEE, MMM d, yyyy').format(converted), style: const TextStyle(color: Color(0xFF34518D))),
          const SizedBox(height: 4),
          Text('${to.name}, ${to.country}', style: const TextStyle(color: Color(0xFF34518D))),
        ]),
      )),
    ]);
  }

  Widget _meeting() {
    final options = [from, to, cities[8]];
    return ListView(padding: const EdgeInsets.all(18), children: [
      Text('Meeting planner', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      Text('Check the current time across your team.', style: TextStyle(color: Colors.grey.shade600)),
      const SizedBox(height: 18),
      ...options.map((city) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 17, vertical: 9),
          leading: const CircleAvatar(backgroundColor: Color(0xFFEAF0FF), child: Icon(Icons.schedule, color: Color(0xFF356AE6))),
          title: Text(city.name, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${city.country} • ${_date(city)}'),
          trailing: Text(_time(city), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        ),
      )),
      const SizedBox(height: 8),
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), child: const Padding(
        padding: EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Meeting tip', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 6),
          Text('Use the Converter tab to choose a date and time, then compare the corresponding local time in another city. Always confirm the final meeting time with your attendees.'),
        ]),
      )),
    ]);
  }
}
