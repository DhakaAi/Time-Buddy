import 'package:flutter_test/flutter_test.dart';
import 'package:timebuddy/main.dart';
import 'package:timezone/data/latest.dart' as tzdata;

void main() {
  testWidgets('TimeBuddy shows primary navigation', (tester) async {
    tzdata.initializeTimeZones();
    await tester.pumpWidget(const TimeBuddyApp());
    await tester.pumpAndSettle();
    expect(find.text('TimeBuddy'), findsOneWidget);
    expect(find.text('World Clock'), findsOneWidget);
    expect(find.text('Converter'), findsOneWidget);
    expect(find.text('Meeting'), findsOneWidget);
  });
}
